﻿#requires -Version 5.1

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

$builderScript = Join-Path $PSScriptRoot 'build-from-folder.ps1'
$script:buildProcess = $null
$script:buildStartedAt = $null
$script:finalizedProcessId = $null
$script:stdoutReadTask = $null
$script:stderrReadTask = $null
$script:stdoutEnded = $true
$script:stderrEnded = $true

function Show-Error([string]$message) {
    [void][System.Windows.Forms.MessageBox]::Show(
        $form,
        $message,
        'PKG Build GUI',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
}

function Quote-Argument([string]$value) {
    return '"' + $value.Replace('"', '\"') + '"'
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'PKG Build GUI'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(960, 690)
$form.MinimumSize = New-Object System.Drawing.Size(800, 560)
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

$root = New-Object System.Windows.Forms.TableLayoutPanel
$root.Dock = 'Fill'
$root.Padding = New-Object System.Windows.Forms.Padding(12)
$root.ColumnCount = 1
$root.RowCount = 7
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$form.Controls.Add($root)

$paths = New-Object System.Windows.Forms.GroupBox
$paths.Text = 'Build paths'
$paths.Dock = 'Top'
$paths.AutoSize = $true
$paths.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
$paths.Padding = New-Object System.Windows.Forms.Padding(10, 18, 10, 10)
$paths.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
[void]$root.Controls.Add($paths, 0, 0)

$pathGrid = New-Object System.Windows.Forms.TableLayoutPanel
$pathGrid.Dock = 'Top'
$pathGrid.AutoSize = $true
$pathGrid.ColumnCount = 4
$pathGrid.RowCount = 3
[void]$pathGrid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 205)))
[void]$pathGrid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$pathGrid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$pathGrid.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$paths.Controls.Add($pathGrid)

function Add-PathControls {
    param(
        [int]$Row,
        [string]$LabelText,
        [bool]$ShowClear = $false
    )

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $LabelText
    $label.AutoSize = $true
    $label.Anchor = 'Left'
    $label.Margin = New-Object System.Windows.Forms.Padding(0, 8, 8, 6)

    $text = New-Object System.Windows.Forms.TextBox
    $text.Dock = 'Fill'
    $text.Margin = New-Object System.Windows.Forms.Padding(0, 4, 8, 4)

    $browse = New-Object System.Windows.Forms.Button
    $browse.Text = 'Browse...'
    $browse.AutoSize = $true
    $browse.MinimumSize = New-Object System.Drawing.Size(88, 27)
    $browse.Margin = New-Object System.Windows.Forms.Padding(0, 2, 6, 2)

    $clear = New-Object System.Windows.Forms.Button
    $clear.Text = 'Clear'
    $clear.AutoSize = $true
    $clear.MinimumSize = New-Object System.Drawing.Size(82, 27)
    $clear.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $clear.Visible = $ShowClear

    [void]$pathGrid.Controls.Add($label, 0, $Row)
    [void]$pathGrid.Controls.Add($text, 1, $Row)
    [void]$pathGrid.Controls.Add($browse, 2, $Row)
    [void]$pathGrid.Controls.Add($clear, 3, $Row)

    return [PSCustomObject]@{
        TextBox = $text
        BrowseButton = $browse
        ClearButton = $clear
    }
}

$sourceControls = Add-PathControls -Row 0 -LabelText 'Source folder:'
$outputControls = Add-PathControls -Row 1 -LabelText 'Output file (.pkg):'
$tempControls = Add-PathControls -Row 2 -LabelText 'Temporary folder (optional):' -ShowClear $true

$txtSource = $sourceControls.TextBox
$btnSource = $sourceControls.BrowseButton
$txtOutput = $outputControls.TextBox
$btnOutput = $outputControls.BrowseButton
$txtTemp = $tempControls.TextBox
$btnTemp = $tempControls.BrowseButton
$btnTempClear = $tempControls.ClearButton

$hint = New-Object System.Windows.Forms.Label
$hint.Text = 'The temporary folder is optional. If left blank, -TemporaryDirectory is not passed.'
$hint.AutoSize = $true
$hint.Margin = New-Object System.Windows.Forms.Padding(205, 0, 0, 8)
[void]$root.Controls.Add($hint, 0, 1)

$options = New-Object System.Windows.Forms.FlowLayoutPanel
$options.Dock = 'Top'
$options.AutoSize = $true
$options.FlowDirection = 'LeftToRight'
$options.WrapContents = $false
$options.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 8)

$lblCompression = New-Object System.Windows.Forms.Label
$lblCompression.Text = 'Compression (-4..9):'
$lblCompression.AutoSize = $true
$lblCompression.Margin = New-Object System.Windows.Forms.Padding(0, 7, 8, 0)
[void]$options.Controls.Add($lblCompression)

$numCompression = New-Object System.Windows.Forms.NumericUpDown
$numCompression.Minimum = -4
$numCompression.Maximum = 9
$numCompression.Value = 7
$numCompression.Width = 60
$numCompression.Margin = New-Object System.Windows.Forms.Padding(0, 3, 24, 0)
[void]$options.Controls.Add($numCompression)

$chkForce = New-Object System.Windows.Forms.CheckBox
$chkForce.Text = 'Overwrite existing files (-Force)'
$chkForce.AutoSize = $true
$chkForce.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
[void]$options.Controls.Add($chkForce)
[void]$root.Controls.Add($options, 0, 2)

$buttons = New-Object System.Windows.Forms.FlowLayoutPanel
$buttons.Dock = 'Top'
$buttons.AutoSize = $true
$buttons.FlowDirection = 'LeftToRight'
$buttons.WrapContents = $false
$buttons.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)

$btnBuild = New-Object System.Windows.Forms.Button
$btnBuild.Text = 'Build'
$btnBuild.AutoSize = $true
$btnBuild.MinimumSize = New-Object System.Drawing.Size(110, 32)
[void]$buttons.Controls.Add($btnBuild)

$btnOpenOutput = New-Object System.Windows.Forms.Button
$btnOpenOutput.Text = 'Open output folder'
$btnOpenOutput.AutoSize = $true
$btnOpenOutput.Enabled = $false
$btnOpenOutput.MinimumSize = New-Object System.Drawing.Size(180, 32)
[void]$buttons.Controls.Add($btnOpenOutput)

$btnClearLog = New-Object System.Windows.Forms.Button
$btnClearLog.Text = 'Clear log'
$btnClearLog.AutoSize = $true
$btnClearLog.MinimumSize = New-Object System.Drawing.Size(110, 32)
[void]$buttons.Controls.Add($btnClearLog)
[void]$root.Controls.Add($buttons, 0, 3)

$statusPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$statusPanel.Dock = 'Top'
$statusPanel.AutoSize = $true
$statusPanel.FlowDirection = 'LeftToRight'
$statusPanel.WrapContents = $false
$statusPanel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 4)

$lblStatusCaption = New-Object System.Windows.Forms.Label
$lblStatusCaption.Text = 'Status:'
$lblStatusCaption.AutoSize = $true
$lblStatusCaption.Margin = New-Object System.Windows.Forms.Padding(0, 4, 6, 0)
[void]$statusPanel.Controls.Add($lblStatusCaption)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = 'Ready'
$lblStatus.AutoSize = $true
$lblStatus.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
[void]$statusPanel.Controls.Add($lblStatus)
[void]$root.Controls.Add($statusPanel, 0, 4)

$lblLog = New-Object System.Windows.Forms.Label
$lblLog.Text = 'Build log:'
$lblLog.AutoSize = $true
$lblLog.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 4)
[void]$root.Controls.Add($lblLog, 0, 5)

$log = New-Object System.Windows.Forms.RichTextBox
$log.Dock = 'Fill'
$log.ReadOnly = $true
$log.WordWrap = $false
$log.DetectUrls = $false
$log.Font = New-Object System.Drawing.Font('Consolas', 9)
$log.HideSelection = $false
[void]$root.Controls.Add($log, 0, 6)

$sourceFolderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
$sourceFolderDialog.Description = 'Select the source project folder'
$sourceFolderDialog.ShowNewFolderButton = $false

$tempFolderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
$tempFolderDialog.Description = 'Select the temporary folder'
$tempFolderDialog.ShowNewFolderButton = $true

$saveDialog = New-Object System.Windows.Forms.SaveFileDialog
$saveDialog.Title = 'Select the output PKG file'
$saveDialog.Filter = 'PKG package (*.pkg)|*.pkg|All files (*.*)|*.*'
$saveDialog.DefaultExt = 'pkg'
$saveDialog.AddExtension = $true
$saveDialog.OverwritePrompt = $false

$btnSource.Add_Click({
    if ($txtSource.Text -and (Test-Path -LiteralPath $txtSource.Text -PathType Container)) {
        $sourceFolderDialog.SelectedPath = $txtSource.Text
    }
    if ($sourceFolderDialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtSource.Text = $sourceFolderDialog.SelectedPath
        if ([string]::IsNullOrWhiteSpace($txtOutput.Text)) {
            $sourceInfo = Get-Item -LiteralPath $sourceFolderDialog.SelectedPath
            if ($null -ne $sourceInfo.Parent) {
                $txtOutput.Text = Join-Path $sourceInfo.Parent.FullName ($sourceInfo.Name + '.pkg')
            }
        }
    }
})

$btnOutput.Add_Click({
    if (-not [string]::IsNullOrWhiteSpace($txtOutput.Text)) {
        try {
            $fullOutput = [IO.Path]::GetFullPath($txtOutput.Text)
            $initialDir = Split-Path -Parent $fullOutput
            if ($initialDir -and (Test-Path -LiteralPath $initialDir -PathType Container)) {
                $saveDialog.InitialDirectory = $initialDir
            }
            $saveDialog.FileName = Split-Path -Leaf $fullOutput
        } catch { }
    } elseif (-not [string]::IsNullOrWhiteSpace($txtSource.Text)) {
        try {
            $sourceItem = Get-Item -LiteralPath $txtSource.Text -ErrorAction Stop
            if ($null -ne $sourceItem.Parent) {
                $saveDialog.InitialDirectory = $sourceItem.Parent.FullName
                $saveDialog.FileName = $sourceItem.Name + '.pkg'
            }
        } catch { }
    }

    if ($saveDialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtOutput.Text = $saveDialog.FileName
    }
})

$btnTemp.Add_Click({
    if ($txtTemp.Text -and (Test-Path -LiteralPath $txtTemp.Text -PathType Container)) {
        $tempFolderDialog.SelectedPath = $txtTemp.Text
    }
    if ($tempFolderDialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtTemp.Text = $tempFolderDialog.SelectedPath
    }
})

$btnTempClear.Add_Click({ $txtTemp.Clear() })
$btnClearLog.Add_Click({ $log.Clear() })

$btnOpenOutput.Add_Click({
    if (-not [string]::IsNullOrWhiteSpace($txtOutput.Text)) {
        try {
            $dir = Split-Path -Parent ([IO.Path]::GetFullPath($txtOutput.Text))
            if (Test-Path -LiteralPath $dir -PathType Container) {
                Start-Process explorer.exe -ArgumentList @($dir)
            }
        } catch { }
    }
})

function Append-LogLine([string]$line) {
    if ($null -eq $line -or $form.IsDisposed) { return }
    if ($form.InvokeRequired) {
        $captured = $line
        [void]$form.BeginInvoke([Action]{ Append-LogLine $captured })
        return
    }
    $log.AppendText($line + [Environment]::NewLine)
    $log.SelectionStart = $log.TextLength
    $log.ScrollToCaret()
}

function Set-BuildControlsEnabled([bool]$enabled) {
    $txtSource.Enabled = $enabled
    $btnSource.Enabled = $enabled
    $txtOutput.Enabled = $enabled
    $btnOutput.Enabled = $enabled
    $txtTemp.Enabled = $enabled
    $btnTemp.Enabled = $enabled
    $btnTempClear.Enabled = $enabled
    $numCompression.Enabled = $enabled
    $chkForce.Enabled = $enabled
    $btnBuild.Enabled = $enabled
}

function Pump-ProcessOutput {
    # Do not use OutputDataReceived/ErrorDataReceived callbacks here.
    # Windows PowerShell 5.1 may invoke those callbacks on a .NET worker thread
    # without a PowerShell runspace, which can terminate the GUI process.
    $maxLinesPerTick = 250

    $count = 0
    while (-not $script:stdoutEnded -and $null -ne $script:stdoutReadTask -and $script:stdoutReadTask.IsCompleted -and $count -lt $maxLinesPerTick) {
        if ($script:stdoutReadTask.IsFaulted) {
            throw $script:stdoutReadTask.Exception.GetBaseException()
        }
        $line = $script:stdoutReadTask.Result
        if ($null -eq $line) {
            $script:stdoutEnded = $true
            $script:stdoutReadTask = $null
            break
        }
        Append-LogLine $line
        $script:stdoutReadTask = $script:buildProcess.StandardOutput.ReadLineAsync()
        $count++
    }

    $count = 0
    while (-not $script:stderrEnded -and $null -ne $script:stderrReadTask -and $script:stderrReadTask.IsCompleted -and $count -lt $maxLinesPerTick) {
        if ($script:stderrReadTask.IsFaulted) {
            throw $script:stderrReadTask.Exception.GetBaseException()
        }
        $line = $script:stderrReadTask.Result
        if ($null -eq $line) {
            $script:stderrEnded = $true
            $script:stderrReadTask = $null
            break
        }
        Append-LogLine ('[stderr] ' + $line)
        $script:stderrReadTask = $script:buildProcess.StandardError.ReadLineAsync()
        $count++
    }
}

function Reset-ProcessState {
    $script:stdoutReadTask = $null
    $script:stderrReadTask = $null
    $script:stdoutEnded = $true
    $script:stderrEnded = $true
}

$pollTimer = New-Object System.Windows.Forms.Timer
$pollTimer.Interval = 100
$pollTimer.Add_Tick({
    if ($null -eq $script:buildProcess) { return }

    try {
        Pump-ProcessOutput

        if ($script:buildProcess.HasExited) {
            # The process may have exited while a final asynchronous ReadLineAsync
            # is still completing. Keep pumping until both redirected streams reach EOF.
            $script:buildProcess.WaitForExit()
            Pump-ProcessOutput

            if (-not $script:stdoutEnded -or -not $script:stderrEnded) {
                return
            }

            if ($script:finalizedProcessId -ne $script:buildProcess.Id) {
                $script:finalizedProcessId = $script:buildProcess.Id
                $exitCode = $script:buildProcess.ExitCode
                $elapsed = (Get-Date) - $script:buildStartedAt

                Append-LogLine ''
                if ($exitCode -eq 0) {
                    Append-LogLine ('=== BUILD SUCCEEDED ({0:hh\:mm\:ss}) ===' -f $elapsed)
                    $lblStatus.Text = 'Build completed successfully'
                    $btnOpenOutput.Enabled = $true
                } else {
                    Append-LogLine ('=== BUILD FAILED: exit code {0} ({1:hh\:mm\:ss}) ===' -f $exitCode, $elapsed)
                    $lblStatus.Text = "Build failed (exit code $exitCode)"
                    $btnOpenOutput.Enabled = $false
                }

                Set-BuildControlsEnabled $true
                $script:buildProcess.Dispose()
                $script:buildProcess = $null
                Reset-ProcessState
            }
        }
    } catch {
        Append-LogLine ('GUI process error: ' + $_.Exception.Message)
        $lblStatus.Text = 'GUI error'
        Set-BuildControlsEnabled $true
        if ($null -ne $script:buildProcess) {
            try { $script:buildProcess.Dispose() } catch { }
            $script:buildProcess = $null
        }
        Reset-ProcessState
    }
})
$pollTimer.Start()

$btnBuild.Add_Click({
    if ($null -ne $script:buildProcess) { return }

    if (-not (Test-Path -LiteralPath $builderScript -PathType Leaf)) {
        Show-Error "build-from-folder.ps1 was not found:`r`n$builderScript"
        return
    }

    $source = $txtSource.Text.Trim()
    $output = $txtOutput.Text.Trim()
    $temp = $txtTemp.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($source) -or -not (Test-Path -LiteralPath $source -PathType Container)) {
        Show-Error 'Select an existing source folder.'
        return
    }

    $keystone = Join-Path $source 'sce_sys\keystone'
    if (-not (Test-Path -LiteralPath $keystone -PathType Leaf)) {
        Show-Error "Required file was not found in the project:`r`nsce_sys\keystone"
        return
    }
    if ((Get-Item -LiteralPath $keystone).Length -ne 96) {
        Show-Error 'sce_sys\keystone must be exactly 96 bytes.'
        return
    }

    if ([string]::IsNullOrWhiteSpace($output)) {
        Show-Error 'Select an output PKG file.'
        return
    }

    try {
        $source = [IO.Path]::GetFullPath($source)
        $output = [IO.Path]::GetFullPath($output)
    } catch {
        Show-Error 'The source folder or output PKG path is invalid.'
        return
    }

    if ([IO.Path]::GetExtension($output) -ine '.pkg') {
        Show-Error 'The output file must have the .pkg extension.'
        return
    }

    if (-not [string]::IsNullOrWhiteSpace($temp)) {
        try {
            $temp = [Environment]::ExpandEnvironmentVariables($temp)
            $temp = [IO.Path]::GetFullPath($temp)
            if (Test-Path -LiteralPath $temp) {
                if (-not (Test-Path -LiteralPath $temp -PathType Container)) {
                    Show-Error 'The specified temporary path exists but is not a folder.'
                    return
                }
            } else {
                [void](New-Item -ItemType Directory -Force -Path $temp)
            }
        } catch {
            Show-Error ('Unable to use the temporary folder: ' + $_.Exception.Message)
            return
        }
        $txtTemp.Text = $temp
    }

    $txtSource.Text = $source
    $txtOutput.Text = $output
    $compression = [int]$numCompression.Value

    $powershellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $powershellExe -PathType Leaf)) {
        $powershellExe = 'powershell.exe'
    }

    $args = @(
        '-NoLogo',
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy', 'Bypass',
        '-File', (Quote-Argument $builderScript),
        '-SourceFolder', (Quote-Argument $source),
        '-OutputPackage', (Quote-Argument $output),
        '-CompressionLevel', $compression.ToString()
    )
    if (-not [string]::IsNullOrWhiteSpace($temp)) {
        $args += @('-TemporaryDirectory', (Quote-Argument $temp))
    }
    if ($chkForce.Checked) { $args += '-Force' }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $powershellExe
    $psi.Arguments = ($args -join ' ')
    $psi.WorkingDirectory = $PSScriptRoot
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    $proc.EnableRaisingEvents = $false

    $log.Clear()
    Append-LogLine ('Source:      ' + $source)
    Append-LogLine ('Output:      ' + $output)
    if ([string]::IsNullOrWhiteSpace($temp)) {
        Append-LogLine 'Temp:        <not specified>'
    } else {
        Append-LogLine ('Temp:        ' + $temp)
    }
    Append-LogLine ('Compression: ' + $compression)
    Append-LogLine ('Force:       ' + $chkForce.Checked)
    Append-LogLine ''

    try {
        Set-BuildControlsEnabled $false
        $btnOpenOutput.Enabled = $false
        $lblStatus.Text = 'Building...'
        $script:buildStartedAt = Get-Date
        $script:finalizedProcessId = $null
$script:stdoutReadTask = $null
$script:stderrReadTask = $null
$script:stdoutEnded = $true
$script:stderrEnded = $true

        $started = $proc.Start()
        if (-not $started) {
            throw 'Failed to start PowerShell.'
        }
        $script:buildProcess = $proc
        $script:stdoutEnded = $false
        $script:stderrEnded = $false
        $script:stdoutReadTask = $proc.StandardOutput.ReadLineAsync()
        $script:stderrReadTask = $proc.StandardError.ReadLineAsync()
    } catch {
        Set-BuildControlsEnabled $true
        $lblStatus.Text = 'Launch error'
        Append-LogLine ('GUI launch error: ' + $_.Exception.ToString())
        try { $proc.Dispose() } catch { }
        $script:buildProcess = $null
        Reset-ProcessState
        Show-Error $_.Exception.Message
    }
})

$form.Add_FormClosing({
    if ($null -ne $script:buildProcess) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            $form,
            'A build is still running. Close the GUI and terminate the process?',
            'PKG Build GUI',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            $_.Cancel = $true
            return
        }
        try {
            & taskkill.exe /PID $script:buildProcess.Id /T /F | Out-Null
        } catch { }
    }
})

if (-not (Test-Path -LiteralPath $builderScript -PathType Leaf)) {
    $lblStatus.Text = 'build-from-folder.ps1 not found'
    $btnBuild.Enabled = $false
}

[void]$form.ShowDialog()
